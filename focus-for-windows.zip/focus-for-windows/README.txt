智能防久坐应用 - Windows 打包说明
=====================================

【环境要求】
- Windows 10 或 Windows 11
- Node.js 16.x 或更高版本
  下载地址: https://nodejs.org (选择 LTS 版本)

【打包步骤】
1. 确保已安装 Node.js
   在命令提示符中输入: node --version
   应该显示版本号，如: v18.0.0

2. 打开命令提示符（Win+R，输入 cmd，回车）

3. 进入此目录
   cd C:\path\to\focus-for-windows

4. 安装依赖（首次需要，约2-3分钟）
   npm install

5. 打包应用（约3-5分钟）
   npm run build:win

6. 获取安装包
   打包完成后，在 dist 文件夹中找到：
   - 智能防久坐 Setup 1.0.0.exe (安装版，推荐)
   - 智能防久坐 1.0.0.exe (便携版)

【常见问题】

Q: npm install 失败？
A: 1. 检查网络连接
   2. 尝试使用国内镜像：
      npm config set registry https://registry.npmmirror.com
      npm install

Q: 打包失败？
A: 1. 删除 node_modules 文件夹
   2. 删除 package-lock.json
   3. 重新运行 npm install

Q: 需要管理员权限吗？
A: 不需要，普通用户权限即可

【打包后】
将 dist 文件夹中的 EXE 文件分享给其他用户即可
文件大小约 150-200 MB（这是正常的 Electron 应用大小）

【联系方式】
如有问题，请联系项目作者

版本: 1.0.0
日期: 2026-05-22
=====================================
